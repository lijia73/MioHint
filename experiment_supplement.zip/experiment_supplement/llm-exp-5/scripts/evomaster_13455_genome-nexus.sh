#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar genome-nexus-evomaster-runner.jar  13455 13456 genome-nexus-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-5/logs/evomaster/log_sut_genome-nexus_13455.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar genome-nexus-evomaster-runner.jar  13455 13456 genome-nexus-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-5/logs/evomaster/log_sut_genome-nexus_13455.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/component/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/model/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/service/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=genome-nexus --seed=1 --sutControllerPort=13455 --outputFolder=/data/repo/EvoMaster/llm-exp-5/tests/genome-nexus --statisticsFile=/data/repo/EvoMaster/llm-exp-5/reports/statistics_genome-nexus_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-5/reports/snapshot_genome-nexus_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.222 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-5/reports/covered_target_file_genome-nexus_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-5/logs/evomaster/log_em_genome-nexus_13455.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=genome-nexus --seed=1 --sutControllerPort=13455 --outputFolder=/data/repo/EvoMaster/llm-exp-5/tests/genome-nexus --statisticsFile=/data/repo/EvoMaster/llm-exp-5/reports/statistics_genome-nexus_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-5/reports/snapshot_genome-nexus_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.222 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-5/reports/covered_target_file_genome-nexus_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-5/logs/evomaster/log_em_genome-nexus_13455.txt 2>&1 

kill $CONTROLLER_PID
