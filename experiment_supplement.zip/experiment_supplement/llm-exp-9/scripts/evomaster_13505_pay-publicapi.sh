#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar pay-publicapi-evomaster-runner.jar  13505 13506 pay-publicapi-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-9/logs/evomaster/log_sut_pay-publicapi_13505.txt 2>&1 &"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar pay-publicapi-evomaster-runner.jar  13505 13506 pay-publicapi-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-9/logs/evomaster/log_sut_pay-publicapi_13505.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_11_maven/cs/rest/pay-publicapi/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=pay-publicapi --seed=1 --sutControllerPort=13505 --outputFolder=/data/repo/EvoMaster/llm-exp-9/tests/pay-publicapi --statisticsFile=/data/repo/EvoMaster/llm-exp-9/reports/statistics_pay-publicapi_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-9/reports/snapshot_pay-publicapi_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.61 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-9/reports/covered_target_file_pay-publicapi_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-9/logs/evomaster/log_em_pay-publicapi_13505.txt 2>&1"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=pay-publicapi --seed=1 --sutControllerPort=13505 --outputFolder=/data/repo/EvoMaster/llm-exp-9/tests/pay-publicapi --statisticsFile=/data/repo/EvoMaster/llm-exp-9/reports/statistics_pay-publicapi_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-9/reports/snapshot_pay-publicapi_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.61 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-9/reports/covered_target_file_pay-publicapi_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-9/logs/evomaster/log_em_pay-publicapi_13505.txt 2>&1 

kill $CONTROLLER_PID
