#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar languagetool-evomaster-runner.jar  14365 14366 languagetool-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-10/logs/evomaster/log_sut_languagetool_14365.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar languagetool-evomaster-runner.jar  14365 14366 languagetool-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /data/repo/EvoMaster/llm-exp-10/logs/evomaster/log_sut_languagetool_14365.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/languagetool/languagetool-core/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/languagetool/languagetool-server/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=languagetool --seed=1 --sutControllerPort=14365 --outputFolder=/data/repo/EvoMaster/llm-exp-10/tests/languagetool --statisticsFile=/data/repo/EvoMaster/llm-exp-10/reports/statistics_languagetool_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-10/reports/snapshot_languagetool_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.42 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-10/reports/covered_target_file_languagetool_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-10/logs/evomaster/log_em_languagetool_14365.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=languagetool --seed=1 --sutControllerPort=14365 --outputFolder=/data/repo/EvoMaster/llm-exp-10/tests/languagetool --statisticsFile=/data/repo/EvoMaster/llm-exp-10/reports/statistics_languagetool_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/data/repo/EvoMaster/llm-exp-10/reports/snapshot_languagetool_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.42 --coveredTargetFile=/data/repo/EvoMaster/llm-exp-10/reports/covered_target_file_languagetool_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true > /data/repo/EvoMaster/llm-exp-10/logs/evomaster/log_em_languagetool_14365.txt 2>&1 

kill $CONTROLLER_PID
