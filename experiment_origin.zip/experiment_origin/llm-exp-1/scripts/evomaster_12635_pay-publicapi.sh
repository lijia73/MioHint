#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar pay-publicapi-evomaster-runner.jar  12635 12636 pay-publicapi-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_pay-publicapi_12635.txt 2>&1 &"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar pay-publicapi-evomaster-runner.jar  12635 12636 pay-publicapi-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_pay-publicapi_12635.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_11_maven/cs/rest/pay-publicapi/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=pay-publicapi --seed=1 --sutControllerPort=12635 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/pay-publicapi --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_pay-publicapi__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_pay-publicapi__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.61 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_pay-publicapi__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_pay-publicapi_12635.txt 2>&1"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=pay-publicapi --seed=1 --sutControllerPort=12635 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/pay-publicapi --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_pay-publicapi__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_pay-publicapi__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.61 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_pay-publicapi__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_pay-publicapi_12635.txt 2>&1 

kill $CONTROLLER_PID
