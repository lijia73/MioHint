#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar gestaohospital-rest-evomaster-runner.jar  12505 12506 gestaohospital-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_gestaohospital-rest_12505.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar gestaohospital-rest-evomaster-runner.jar  12505 12506 gestaohospital-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_gestaohospital-rest_12505.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/gestaohospital/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=gestaohospital-rest --seed=1 --sutControllerPort=12505 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/gestaohospital-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_gestaohospital-rest__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_gestaohospital-rest__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.61 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_gestaohospital-rest__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_gestaohospital-rest_12505.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=gestaohospital-rest --seed=1 --sutControllerPort=12505 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/gestaohospital-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_gestaohospital-rest__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_gestaohospital-rest__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.61 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_gestaohospital-rest__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_gestaohospital-rest_12505.txt 2>&1 

kill $CONTROLLER_PID
