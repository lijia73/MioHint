#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar cwa-verification-evomaster-runner.jar  12555 12556 cwa-verification-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_cwa-verification_12555.txt 2>&1 &"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar cwa-verification-evomaster-runner.jar  12555 12556 cwa-verification-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_cwa-verification_12555.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_11_maven/cs/rest/cwa-verification-server/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=cwa-verification --seed=1 --sutControllerPort=12555 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/cwa-verification --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_cwa-verification__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_cwa-verification__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.161 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_cwa-verification__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_cwa-verification_12555.txt 2>&1"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=cwa-verification --seed=1 --sutControllerPort=12555 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/cwa-verification --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_cwa-verification__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_cwa-verification__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.161 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_cwa-verification__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_cwa-verification_12555.txt 2>&1 

kill $CONTROLLER_PID
