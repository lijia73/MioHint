#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar rest-ncs-evomaster-runner.jar  12395 12396 rest-ncs-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_rest-ncs_12395.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar rest-ncs-evomaster-runner.jar  12395 12396 rest-ncs-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_rest-ncs_12395.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest/artificial/ncs/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=rest-ncs --seed=1 --sutControllerPort=12395 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/rest-ncs --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_rest-ncs__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_rest-ncs__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.102 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_rest-ncs__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_rest-ncs_12395.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=rest-ncs --seed=1 --sutControllerPort=12395 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/rest-ncs --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_rest-ncs__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_rest-ncs__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.102 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_rest-ncs__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_rest-ncs_12395.txt 2>&1 

kill $CONTROLLER_PID
