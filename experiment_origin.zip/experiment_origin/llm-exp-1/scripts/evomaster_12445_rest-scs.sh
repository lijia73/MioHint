#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar rest-scs-evomaster-runner.jar  12445 12446 rest-scs-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_rest-scs_12445.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar rest-scs-evomaster-runner.jar  12445 12446 rest-scs-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_sut_rest-scs_12445.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest/artificial/scs/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=rest-scs --seed=1 --sutControllerPort=12445 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/rest-scs --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_rest-scs_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_rest-scs_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.202 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_rest-scs_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_rest-scs_12445.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=rest-scs --seed=1 --sutControllerPort=12445 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-1/tests/rest-scs --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/statistics_rest-scs_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/snapshot_rest-scs_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.202 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-1/reports/covered_target_file_rest-scs_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-1/logs/evomaster/log_em_rest-scs_12445.txt 2>&1 

kill $CONTROLLER_PID
