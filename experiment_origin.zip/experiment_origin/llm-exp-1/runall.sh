#!/bin/bash

# 获取当前脚本所在目录
cd "$(dirname "$0")"

# 获取CPU核心数
num_cores=$(nproc)-1

# 创建一个FIFO队列
fifo="/tmp/$$.fifo"
mkfifo "$fifo"
exec 6<>"$fifo"
rm "$fifo"

# 初始化FIFO队列
for ((i=0; i<num_cores; i++)); do
    echo
done >&6

# 遍历脚本文件并执行
for s in scripts/*.sh; do
    # 从FIFO队列中读取一个空位
    read -u 6
    {
        echo "Going to start $s"
        bash "$s"
        # 任务完成后，向FIFO队列中写入一个空位
        echo >&6
    } &
done

# 等待所有后台任务完成
wait

# 关闭文件描述符
exec 6>&-

echo "All tasks completed."