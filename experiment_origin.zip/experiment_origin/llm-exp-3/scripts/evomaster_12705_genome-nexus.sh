#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar genome-nexus-evomaster-runner.jar  12705 12706 genome-nexus-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_genome-nexus_12705.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar genome-nexus-evomaster-runner.jar  12705 12706 genome-nexus-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_genome-nexus_12705.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/component/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/model/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/genome-nexus/service/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=genome-nexus --seed=1 --sutControllerPort=12705 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/genome-nexus --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_genome-nexus__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_genome-nexus__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.201 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_genome-nexus__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_genome-nexus_12705.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --testSuiteFileName=EM__true_1_Test --labelForExperiments=_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=genome-nexus --seed=1 --sutControllerPort=12705 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/genome-nexus --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_genome-nexus__true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_genome-nexus__true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.201 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_genome-nexus__true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_genome-nexus_12705.txt 2>&1 

kill $CONTROLLER_PID
