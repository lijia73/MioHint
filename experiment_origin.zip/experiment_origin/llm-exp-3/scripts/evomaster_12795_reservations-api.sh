#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar reservations-api-evomaster-runner.jar  12795 12796 reservations-api-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_reservations-api_12795.txt 2>&1 &"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar reservations-api-evomaster-runner.jar  12795 12796 reservations-api-sut.jar 1200 "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_reservations-api_12795.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_11_gradle/cs/rest/reservations-api/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=reservations-api --seed=1 --sutControllerPort=12795 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/reservations-api --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_reservations-api__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_reservations-api__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.3.121 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_reservations-api__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_reservations-api_12795.txt 2>&1"
echo

"/usr/lib/jvm/java-11-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=reservations-api --seed=1 --sutControllerPort=12795 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/reservations-api --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_reservations-api__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_reservations-api__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.3.121 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_reservations-api__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_reservations-api_12795.txt 2>&1 

kill $CONTROLLER_PID
