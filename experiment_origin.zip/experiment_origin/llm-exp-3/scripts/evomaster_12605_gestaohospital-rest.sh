#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar gestaohospital-rest-evomaster-runner.jar  12605 12606 gestaohospital-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_gestaohospital-rest_12605.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar gestaohospital-rest-evomaster-runner.jar  12605 12606 gestaohospital-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_gestaohospital-rest_12605.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/gestaohospital/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=gestaohospital-rest --seed=1 --sutControllerPort=12605 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/gestaohospital-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_gestaohospital-rest_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_gestaohospital-rest_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.1 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_gestaohospital-rest_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_gestaohospital-rest_12605.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=gestaohospital-rest --seed=1 --sutControllerPort=12605 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/gestaohospital-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_gestaohospital-rest_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_gestaohospital-rest_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.2.1 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_gestaohospital-rest_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_gestaohospital-rest_12605.txt 2>&1 

kill $CONTROLLER_PID
