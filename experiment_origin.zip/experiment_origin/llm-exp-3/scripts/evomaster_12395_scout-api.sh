#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar scout-api-evomaster-runner.jar  12395 12396 scout-api-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_scout-api_12395.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar scout-api-evomaster-runner.jar  12395 12396 scout-api-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_sut_scout-api_12395.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/scout-api/api/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/scout-api/auth/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/scout-api/data-access/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest/original/scout-api/data-batch-jobs/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=scout-api --seed=1 --sutControllerPort=12395 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/scout-api --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_scout-api_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_scout-api_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.102 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_scout-api_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_scout-api_12395.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --testSuiteFileName=EM_default_1_Test --labelForExperiments=default --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=scout-api --seed=1 --sutControllerPort=12395 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-3/tests/scout-api --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/statistics_scout-api_default_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/snapshot_scout-api_default_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.0.102 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-3/reports/covered_target_file_scout-api_default_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-3/logs/evomaster/log_em_scout-api_12395.txt 2>&1 

kill $CONTROLLER_PID
