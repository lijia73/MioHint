#!/bin/bash 



echo "Starting EM Runner with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar ocvn-rest-evomaster-runner.jar  12495 12496 ocvn-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-2/logs/evomaster/log_sut_ocvn-rest_12495.txt 2>&1 &"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms1G -Xmx2G -Dem.muteSUT=true -Devomaster.instrumentation.jar.path=evomaster-agent.jar -jar ocvn-rest-evomaster-runner.jar  12495 12496 ocvn-rest-sut.jar 1200 "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  > /home/ubuntu/EvoMaster/llm-exp-2/logs/evomaster/log_sut_ocvn-rest_12495.txt 2>&1 &

CONTROLLER_PID=$! 

sleep 20 

export OPENAI_TOKEN="xxx?"
export REPO_PATH="/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/ocvn/web/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/ocvn/persistence-mongodb/src/main/java,/home/ubuntu/EMB/jdk_8_maven/cs/rest-gui/ocvn/persistence/src/main/java"

echo "Starting EvoMaster with: "/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=ocvn-rest --seed=1 --sutControllerPort=12495 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-2/tests/ocvn-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/statistics_ocvn-rest__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/snapshot_ocvn-rest__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.41 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/covered_target_file_ocvn-rest__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-2/logs/evomaster/log_em_ocvn-rest_12495.txt 2>&1"
echo

"/usr/lib/jvm/java-8-openjdk-amd64"/bin/java  -Xms2G -Xmx4G  -jar evomaster.jar  --enableLLMAssistedRequestGeneration=true --enableValueExpansion=true --testSuiteFileName=EM__true_true_1_Test --labelForExperiments=_true_true --stoppingCriterion=TIME --maxTime=1h --statisticsColumnId=ocvn-rest --seed=1 --sutControllerPort=12495 --outputFolder=/home/ubuntu/EvoMaster/llm-exp-2/tests/ocvn-rest --statisticsFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/statistics_ocvn-rest__true_true_1.csv --snapshotInterval=5 --snapshotStatisticsFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/snapshot_ocvn-rest__true_true_1.csv --appendToStatisticsFile=true --writeStatistics=true --showProgress=false --testSuiteSplitType=NONE --exportCoveredTarget=true --externalServiceIP=127.0.1.41 --coveredTargetFile=/home/ubuntu/EvoMaster/llm-exp-2/reports/covered_target_file_ocvn-rest__true_true_1.txt --useExtraSqlDbConstraintsProbability=0.9 --forceSqlAllColumnInsertion=true >> /home/ubuntu/EvoMaster/llm-exp-2/logs/evomaster/log_em_ocvn-rest_12495.txt 2>&1 

kill $CONTROLLER_PID
